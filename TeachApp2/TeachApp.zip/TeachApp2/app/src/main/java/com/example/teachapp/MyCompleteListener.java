package com.example.teachapp;

public interface MyCompleteListener {

   void onSuccess();
   void onFailure();

}

